globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/A6-I8VqBzfoEQckX1Yjz7/_buildManifest.js",
    "static/A6-I8VqBzfoEQckX1Yjz7/_ssgManifest.js",
    "static/A6-I8VqBzfoEQckX1Yjz7/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/15xrurgzs99gv.js",
    "static/chunks/0dgq26a5_oy.a.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/02g3221oh~3le.js",
    "static/chunks/turbopack-05poq_ye6dti6.js"
  ]
};
